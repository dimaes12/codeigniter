
<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Meja extends CI_Controller {

	public function index()
	{
		
	}

}

/* End of file meja.php */
/* Location: ./application/controllers/meja.php */



?>